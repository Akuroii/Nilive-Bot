# Batch 2 manifest (deletion only, NOT committed)

- Batch 2 base = Batch 1 checkpoint commit: `4bc4d4f45a96360f7dfd94650c8fba41d0676f2f` (parent `5a9eec491ac70790c077a4702981a0befdc5b371` = `main`)
- Working branch: `cleanup/batch2-root-identical-py` (local; HEAD still equals the checkpoint; 74 deletions staged, nothing committed)
- Appendix A candidates (from `phase2_audit_report.md`, parsed, not reconstructed): **75**
- Actually deleted: **74**  | Held: **1**
- Patch: `batch2-deletions.patch` sha256 `ae6e3aa2191baa6cbb9f8e534be0f8efd287af3562dc6cdbade1cff7e837c36e` (74 `deleted file` entries, 0 other entries). Reverse and forward apply both reproduce the exact trees (0 differences).
- `git diff --check`: clean (exit 0). Unstaged/untracked: 0. `main`, the Batch 1 branch and checkpoint commit unchanged.

## Held (1)

| Path | Canonical twin | Reason |
|---|---|---|
| `test_phase1_runtime.py` | `scripts/test_phase1_runtime.py` (byte-identical) | Root `test_phase2_backend.py` (not an Appendix A item, still present) does `import test_phase1_runtime as runtime_tests` at line 21 and executes it from repo root: pre-deletion it runs 39 tests (1 failure, 6 errors; the failure is the known baseline one). Deleting the root copy would break that import. Revisit together with root `test_phase2_backend.py` (Batch 3 decision). |

Examined and cleared (not blocking): `test_rank_integration.py` is imported by `scripts/verify_currency_font_color.py:27`, but line 26 inserts that script's own directory at `sys.path[0]` first, so the `scripts/` copy is used (confirmed: verify script passes pre and post).

## Verification performed

1. Per file: exists and tracked; canonical twin exists and tracked; sha256 recomputed and bytes compared (identical); neither file touched in `5a9eec4..HEAD`; blob at `5a9eec4` equals current blob. Result: 75/75.
2. Static imports (AST over all 388 tracked `.py`, incl. root-relative imports): only 2 stems had importers outside the candidate set (see above); others only imported by other candidates or nobody.
3. Dynamic imports: 85 sites; 28 non-constant (all `load_extension(cog)` lists, probe loaders, `compile(tree)` of `main.py`, shims running `scripts/` copies); constant args are package-qualified (`cogs.*`, `utils.*`, `dashboard.*`), not root modules.
4. Path/name references in code and config: every bare `NAME.py` hit is a comment or a path built from `ROOT, "cogs", ...` components pointing at canonical dirs. `Dockerfile`, `start.sh`, `install.sh`, `run_all.sh`, `package.json`, `requirements.txt`, `.gitignore`, CI example name no candidate. CI example globs only `scripts/test_*.py`. No pytest/conftest/tox/pyproject discovery config. 5 `subprocess` sites run `-c` code or `docs/.../reproduce_inventory_ambiguity.py`.
5. Scanning tests walk `ROOT` or canonical subdirs; verified empirically below.

## Before / after (same command `python <file>`, cwd = tree root, `PYTHONPATH=<tree>`, `OWNER_ID` set, `PYTHONDONTWRITEBYTECODE=1`, same venv; pre = export of checkpoint 715 files, post = 641 files)

| Test | exit pre/post | result pre = post |
|---|---|---|
| `scripts/test_currency_icon.py` | 0/0 | 275 passed |
| `scripts/test_inventory_actions.py` | 0/0 | 36 passed |
| `scripts/test_reward_name_conflicts.py` | 0/0 | 48 passed |
| `scripts/test_workstream3_tables_acceptance.py` | 0/0 | 4 passed |
| `scripts/test_xp_safety_audit.py` | 0/0 | 121 passed |
| `scripts/test_rank_integration.py` | 0/0 | "ALL INTEGRATION CASES PASSED" |
| `scripts/verify_currency_font_color.py` | 0/0 | "VERIFICATION RENDER PASSED" |
| `test_phase2_backend.py (root)` | 1/1 | 32 passed, 1 failed, 6 errors (Ran 39); identical set of failing test names (hash-equal) |
| `test_boost_role_race.py, test_db_migration_concurrency.py, test_inventory_timed_expiry.py, test_pr105_fixes.py, test_pr107_slot_races.py` | 0/0 each | no summary line printed; same output pre/post |
| `test_delivery_safety.py` | 0/0 | 16 passed |
| `test_purchase_grant_ledger.py` | 0/0 | 29 passed |
| `test_role_retention.py` | 0/0 | 25 passed |
| `test_timed_ownership.py` | 0/0 | 247 passed |
| `import database / main / dashboard.app` | 0/0 | ok |
| `syntax of every .py` | 0/0 | 387 files pre, 313 post (74 fewer), 0 bad |

Comparison: 0 newly introduced failures, 0 resolved, 1 pre-existing failure group reproduced identically (root `test_phase2_backend.py`, same failing tests; the 1 failure matches the Batch 1 baseline `test_phase2_backend.py`). Environment limits: no Playwright browser, no real Discord, no Railway.

## Not run (stated, not claimed)
- Full Batch 1 matrix (118 tests + JS suite): not rerun, no specific reason after the dependency analysis. Probe suite `tools/alias_probes/run_all.sh` and the 74 deleted root probe copies were not executed. Dashboard routes were not rendered in a browser.

## Unresolved risks
- Anyone running a deleted root copy by hand from the repo root (for example `python p8_acceptance.py`) would now get "file not found"; the same file exists in `tools/alias_probes/` or `scripts/`. Not detectable from the repo. Everything is recoverable from commit `5a9eec4`.
- Graph/index noise drops once the root copies are gone; nothing else changes at runtime (Docker runs `start.sh` -> `main.py` + `dashboard/app.py`).

## Deleted paths (74) with canonical counterpart

| Deleted | Canonical (byte-identical) | sha256[:16] | bytes |
|---|---|---|---|
| `afk.py` | `cogs/afk.py` | `7be597c68445e7af` | 37602 |
| `app_emoji_cache.py` | `utils/app_emoji_cache.py` | `e1d3d89fd962eb1a` | 3347 |
| `async_utils.py` | `dashboard/utils/async_utils.py` | `ee574b3927153263` | 2601 |
| `auditlog.py` | `cogs/auditlog.py` | `a16113b92dfe2dff` | 6080 |
| `backup.py` | `cogs/backup.py` | `79003bee7481aca5` | 8653 |
| `backups.py` | `dashboard/api/backups.py` | `4f4f81977c254b41` | 6031 |
| `botprofile.py` | `cogs/botprofile.py` | `506f74d714d374cc` | 3263 |
| `check_icon.py` | `dashboard/utils/check_icon.py` | `1f6b478a7ba8944d` | 3579 |
| `clone_to_staging.py` | `scripts/clone_to_staging.py` | `91b31f6401cf290d` | 3439 |
| `command_aliases.py` | `cogs/command_aliases.py` | `5101e8d5af4e27c7` | 42636 |
| `command_gating.py` | `utils/command_gating.py` | `ebec6f5ae4078301` | 6961 |
| `creator_notify_engine.py` | `utils/creator_notify_engine.py` | `e02de48c430f7fa3` | 38066 |
| `currency.py` | `utils/currency.py` | `7f12eb2aa99bfa64` | 11947 |
| `currency_ctx.py` | `dashboard/utils/currency_ctx.py` | `764f6589da1ab04f` | 9416 |
| `customcommands.py` | `cogs/customcommands.py` | `68430707447c89b7` | 13847 |
| `discord_user_cache.py` | `utils/discord_user_cache.py` | `482fc3bf342e43b5` | 10018 |
| `economy.py` | `cogs/economy.py` | `b7e5066c335ed9f2` | 13723 |
| `embed_schema.py` | `utils/embed_schema.py` | `582064751a0efd10` | 17662 |
| `embedbuilder.py` | `cogs/embedbuilder.py` | `46b2bbeaf633f0c9` | 11221 |
| `emoji.py` | `utils/emoji.py` | `e22189b9b625700e` | 23920 |
| `formatters.py` | `utils/formatters.py` | `38ebfaa98a981e28` | 5766 |
| `health.py` | `cogs/health.py` | `fbad84dc4a5489fe` | 5626 |
| `item_catalog.py` | `utils/item_catalog.py` | `fa8d08bb4c2592c3` | 5548 |
| `message_router.py` | `utils/message_router.py` | `868fbf0b753e58d5` | 14731 |
| `minigames.py` | `cogs/minigames.py` | `d1c67e2a879b1d17` | 28490 |
| `missions.py` | `cogs/missions.py` | `878003580b13012c` | 31043 |
| `moderation.py` | `cogs/moderation.py` | `2de7dd50a320a850` | 32430 |
| `p10_full_boot.py` | `tools/alias_probes/p10_full_boot.py` | `9f8118ea14875694` | 5838 |
| `p12_real_message_surface.py` | `tools/alias_probes/p12_real_message_surface.py` | `3433e1c0112a976e` | 12675 |
| `p1_ordering.py` | `tools/alias_probes/p1_ordering.py` | `6de6f20cd052a38a` | 3267 |
| `p2_real_cog.py` | `tools/alias_probes/p2_real_cog.py` | `c1df3ef9c3d3e237` | 9250 |
| `p4_flask.py` | `tools/alias_probes/p4_flask.py` | `3535d186f162e3f8` | 10967 |
| `p5b_runtime.py` | `tools/alias_probes/legacy/p5b_runtime.py` | `dda578747f69da80` | 5982 |
| `p5c_conflicts.py` | `tools/alias_probes/legacy/p5c_conflicts.py` | `58d5260685accdb8` | 5616 |
| `p6_race.py` | `tools/alias_probes/p6_race.py` | `3de0a8d46484a981` | 8808 |
| `p7_prototype.py` | `tools/alias_probes/legacy/p7_prototype.py` | `ff924f365b198f44` | 7740 |
| `p8_acceptance.py` | `tools/alias_probes/p8_acceptance.py` | `71c50d664e00a93d` | 27936 |
| `report.py` | `cogs/report.py` | `c884cec297f00ebe` | 14032 |
| `shop_categories.py` | `dashboard/api/shop_categories.py` | `5a2184e2a6c997b3` | 15853 |
| `sticky.py` | `cogs/sticky.py` | `8b55b99487a0ffcf` | 5146 |
| `test_afk.py` | `scripts/test_afk.py` | `b51ea855a0ce91cf` | 58664 |
| `test_afk_dashboard.py` | `scripts/test_afk_dashboard.py` | `ff07e6b41969bc45` | 5468 |
| `test_check_emoji.py` | `scripts/test_check_emoji.py` | `cc747db607d104e3` | 48154 |
| `test_currency_icon.py` | `scripts/test_currency_icon.py` | `5f332cad9b4bdecb` | 33248 |
| `test_heartbeat.py` | `scripts/test_heartbeat.py` | `2e1492647a63ed91` | 7593 |
| `test_lock.py` | `scripts/test_lock.py` | `338f8ea2116d28a5` | 13306 |
| `test_minigame_api.py` | `scripts/test_minigame_api.py` | `233f8bf2088847b7` | 33223 |
| `test_minigame_engines.py` | `scripts/test_minigame_engines.py` | `7cf80f6c307c6e4c` | 34165 |
| `test_minigame_migration.py` | `scripts/test_minigame_migration.py` | `a4cf1573401c3692` | 19690 |
| `test_minigame_spawn.py` | `scripts/test_minigame_spawn.py` | `3900a780392ba0c2` | 44378 |
| `test_minigame_store.py` | `scripts/test_minigame_store.py` | `e4384773c550f6b0` | 20744 |
| `test_missions_v2.py` | `scripts/test_missions_v2.py` | `5b614f1c023cc7a1` | 56861 |
| `test_phase1_prestige.py` | `scripts/test_phase1_prestige.py` | `ff3ad8b247ad58f4` | 14978 |
| `test_prestige.py` | `scripts/test_prestige.py` | `4d7749212ad1820f` | 27291 |
| `test_prestige_api.py` | `scripts/test_prestige_api.py` | `4087ef7302c2a6ea` | 5187 |
| `test_purge.py` | `scripts/test_purge.py` | `7ec8fa606d5a20bd` | 6557 |
| `test_rank_integration.py` | `scripts/test_rank_integration.py` | `4b9ebceef8fc83e3` | 7952 |
| `test_shop_categories_api.py` | `scripts/test_shop_categories_api.py` | `e2d889b5e14f155b` | 22686 |
| `test_shop_json_body_api.py` | `scripts/test_shop_json_body_api.py` | `335c0010ae823af9` | 1928 |
| `test_shop_publications.py` | `scripts/test_shop_publications.py` | `0ae18bf46efe957c` | 19957 |
| `test_shop_select_dispatch.py` | `scripts/test_shop_select_dispatch.py` | `a1e03b352f48d157` | 4108 |
| `test_tree_error.py` | `scripts/test_tree_error.py` | `b750adc17f756231` | 7257 |
| `test_vi_lifecycle.py` | `scripts/test_vi_lifecycle.py` | `c4a0ae1bd28a9992` | 25903 |
| `test_vi_shop_api.py` | `scripts/test_vi_shop_api.py` | `4b3ca047f5dd2050` | 5049 |
| `test_wallet.py` | `scripts/test_wallet.py` | `980584b093d46d53` | 20504 |
| `test_wallet_phase2.py` | `scripts/test_wallet_phase2.py` | `c9fa0e806fb900fc` | 14548 |
| `tickets.py` | `cogs/tickets.py` | `de056781e6f43498` | 27715 |
| `timezone.py` | `utils/timezone.py` | `b58e4ade05f0f2ed` | 7473 |
| `trade.py` | `cogs/trade.py` | `c13ec49d74adf592` | 21365 |
| `triggers.py` | `cogs/triggers.py` | `0c009cf911ef4af0` | 15978 |
| `user_identity.py` | `dashboard/utils/user_identity.py` | `c4a3afe4e552d1f7` | 1966 |
| `verify_currency_font_color.py` | `scripts/verify_currency_font_color.py` | `97f8389937574450` | 3479 |
| `verify_runtime_path.py` | `scripts/verify_runtime_path.py` | `e095039ddbf0028a` | 21491 |
| `youtube.py` | `cogs/youtube.py` | `132eceb9a2959cbf` | 27030 |
