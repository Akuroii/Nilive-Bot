import aiosqlite
import asyncio
import os
import sys

# STAGING / PRODUCTION SEPARATION: set NERO_ENVIRONMENT=staging on a
# second deploy (e.g. a throwaway Oracle Cloud instance or a local dev
# box) to point at a separate DB file without touching production data.
# Unset (the default) behaves exactly as before — DATABASE_PATH (or the
# hardcoded /app/data/nero.db default) is used untouched, so existing
# deploys need zero config changes.
NERO_ENVIRONMENT = os.getenv("NERO_ENVIRONMENT", "production").strip().lower()

if NERO_ENVIRONMENT == "staging":
    DB_PATH = os.getenv("STAGING_DATABASE_PATH", "/app/data/nero_staging.db")
    # Safety guard: if someone sets NERO_ENVIRONMENT=staging but a
    # STAGING_DATABASE_PATH that (accidentally or via copy-paste) points
    # at the same file as production, refuse to start rather than let a
    # staging session silently read/write prod data.
    _prod_path = os.getenv("DATABASE_PATH", "/app/data/nero.db")
    if os.path.abspath(DB_PATH) == os.path.abspath(_prod_path):
        print("=" * 60)
        print("FATAL: NERO_ENVIRONMENT=staging but STAGING_DATABASE_PATH")
        print("  resolves to the SAME file as production DATABASE_PATH.")
        print(f"  Both resolve to: {os.path.abspath(DB_PATH)}")
        print("  -> Set STAGING_DATABASE_PATH to a different path.")
        print("=" * 60)
        sys.exit(1)
else:
    DB_PATH = os.getenv("DATABASE_PATH", "/app/data/nero.db")

# SECURITY FIX: OWNER_DISCORD_ID previously had a hardcoded fallback —
# anyone deploying from this source without setting OWNER_ID got a
# working bot that silently granted dashboard owner access to whatever
# Discord account that literal ID belonged to. Now required; the
# process refuses to start rather than boot with a wrong or absent
# owner. If this is your own existing deploy, set OWNER_ID to your
# Discord user ID (it was previously hardcoded to 704453350384730237)
# as an env var before redeploying.
_owner_id_raw = os.getenv("OWNER_ID", "").strip()
if not _owner_id_raw:
    print("=" * 60)
    print("FATAL: OWNER_ID is missing or empty.")
    print("  -> Set OWNER_ID to your Discord user ID as an env var.")
    print("  -> This used to default to a hardcoded ID baked into the")
    print("     source — that fallback has been removed for security.")
    print("=" * 60)
    sys.exit(1)
OWNER_DISCORD_ID = int(_owner_id_raw)


LEVELING_CONFIG_BASELINE_MIGRATION = "message-xp-10s-spam-window-20s-v1"
# Separate one-shot marker: databases that already recorded the baseline marker
# above must still receive this threshold migration exactly once.
LEVELING_SPAM_THRESHOLD_MIGRATION = "spam-threshold-legacy-default-3-to-10-v1"
LEVELING_CONFIG_CREATE_SQL = """
    CREATE TABLE IF NOT EXISTS leveling_config (
        guild_id                 INTEGER PRIMARY KEY,
        message_xp_enabled       INTEGER NOT NULL DEFAULT 1,
        xp_per_word              INTEGER DEFAULT 1,
        xp_min_per_message       INTEGER DEFAULT 5,
        xp_max_per_message       INTEGER DEFAULT 50,
        xp_cooldown_seconds      INTEGER DEFAULT 10,
        voice_xp_enabled         INTEGER DEFAULT 1,
        voice_xp_per_minute      INTEGER DEFAULT 3,
        voice_require_unmuted    INTEGER DEFAULT 1,
        voice_farming_guard      INTEGER DEFAULT 1,
        spam_detection_enabled   INTEGER DEFAULT 1,
        spam_threshold           INTEGER DEFAULT 10,
        spam_window_seconds      INTEGER DEFAULT 20,
        -- Deprecated storage only: preserve historical values, but the runtime
        -- now applies the incident-based divisor and rolling cap below.
        spam_xp_penalty          INTEGER DEFAULT 10,
        spam_xp_penalty_divisor  INTEGER DEFAULT 1000,
        levelup_announce         INTEGER DEFAULT 1,
        levelup_channel_id       INTEGER,
        levelup_message          TEXT,
        levelup_embed_data       TEXT,
        remove_old_reward_role   INTEGER DEFAULT 0,
        updated_at               TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
"""


async def migrate_leveling_config(db):
    """Bring the Leveling config schema and legacy baselines forward once.

    The marker makes the data migration one-shot: existing rows receive the
    approved cooldown/window baselines exactly once, while later bot/dashboard
    startups never overwrite subsequent administrator edits.

    Architecture note (intentional): the legacy ``enabled`` column is no longer
    a master Leveling switch. It is renamed to ``message_xp_enabled`` and its
    stored value is carried over unchanged, but it now gates Message XP only.
    Voice XP, missions, events, minigames, tags and claims are independent XP
    sources with their own switches. This migration deliberately does not copy
    a legacy ``enabled=0`` into any other setting and the global gate is not
    restored.

    A NULL legacy ``enabled`` (the column was nullable) is normalized to 1, the
    value the runtime already treated it as, so the NOT NULL rebuild cannot fail
    and abort init_db().

    Separately and once (its own marker), ``spam_threshold`` is moved from the
    old default of 3 to the new default of 10 only where the stored value is
    still exactly 3. Any other (administrator-customized) value is preserved.
    The SQL default for spam_threshold is 10 for future rows; any table rebuild
    copies existing per-guild values verbatim.
    """
    await db.execute("BEGIN IMMEDIATE")
    try:
        await db.execute(LEVELING_CONFIG_CREATE_SQL)
        cursor = await db.execute("PRAGMA table_info(leveling_config)")
        columns = {row[1] for row in await cursor.fetchall()}

        if "message_xp_enabled" not in columns and "enabled" in columns:
            await db.execute(
                "ALTER TABLE leveling_config RENAME COLUMN enabled TO message_xp_enabled")
            columns.remove("enabled")
            columns.add("message_xp_enabled")
        elif "message_xp_enabled" not in columns:
            await db.execute(
                "ALTER TABLE leveling_config ADD COLUMN message_xp_enabled "
                "INTEGER NOT NULL DEFAULT 1")
            columns.add("message_xp_enabled")
        elif "enabled" in columns:
            # Defensive support for a partial rollout that briefly stored both.
            await db.execute("""
                UPDATE leveling_config SET message_xp_enabled=enabled
                WHERE enabled IS NOT NULL
            """)
            await db.execute("ALTER TABLE leveling_config DROP COLUMN enabled")
            columns.remove("enabled")

        # Legacy ``enabled`` was nullable and the runtime read NULL as ON (the
        # default). Normalize it before any NOT NULL table rebuild below.
        await db.execute(
            "UPDATE leveling_config SET message_xp_enabled=1 "
            "WHERE message_xp_enabled IS NULL")

        if "spam_window_seconds" not in columns:
            await db.execute(
                "ALTER TABLE leveling_config ADD COLUMN spam_window_seconds "
                "INTEGER DEFAULT 20")
            columns.add("spam_window_seconds")
        if "spam_xp_penalty_divisor" not in columns:
            await db.execute(
                "ALTER TABLE leveling_config ADD COLUMN spam_xp_penalty_divisor "
                "INTEGER DEFAULT 1000")
            columns.add("spam_xp_penalty_divisor")
        # Voice-farming guard (alone / deafened / AFK). Additive: existing
        # rows get 1 (ON) from the column default, i.e. the pre-existing
        # always-blocked behaviour, so an upgrade changes nothing by itself.
        if "voice_farming_guard" not in columns:
            await db.execute(
                "ALTER TABLE leveling_config ADD COLUMN voice_farming_guard "
                "INTEGER DEFAULT 1")
            columns.add("voice_farming_guard")
        # Keep the old fixed-penalty column as inert compatibility storage.
        # Its value has no safe/arbitrary mapping to the new incident divisor;
        # the listener and Dashboard never read or write it.

        # SQLite cannot alter an existing column's DEFAULT. Rebuild only when
        # a legacy default is still present so direct inserts on an upgraded
        # database use the same baseline as fresh databases and Dashboard saves.
        cursor = await db.execute("PRAGMA table_info(leveling_config)")
        schema = await cursor.fetchall()
        defaults = {row[1]: row[4] for row in schema}
        wanted_defaults = {
            "xp_cooldown_seconds": "10",
            "spam_threshold": "10",
            "spam_window_seconds": "20",
            "spam_xp_penalty_divisor": "1000",
        }
        if any(str(defaults.get(name)) != value
               for name, value in wanted_defaults.items()):
            await db.execute(
                "ALTER TABLE leveling_config RENAME TO leveling_config_legacy")
            await db.execute(LEVELING_CONFIG_CREATE_SQL)
            old_cursor = await db.execute(
                "PRAGMA table_info(leveling_config_legacy)")
            old_columns = {row[1] for row in await old_cursor.fetchall()}
            new_cursor = await db.execute(
                "PRAGMA table_info(leveling_config)")
            new_columns = [row[1] for row in await new_cursor.fetchall()]
            shared = [name for name in new_columns if name in old_columns]
            names = ", ".join(f'"{name}"' for name in shared)
            await db.execute(
                f"INSERT INTO leveling_config ({names}) "
                f"SELECT {names} FROM leveling_config_legacy")
            await db.execute("DROP TABLE leveling_config_legacy")

        await db.execute("""
            CREATE TABLE IF NOT EXISTS leveling_config_migrations (
                migration_name TEXT PRIMARY KEY,
                applied_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        cursor = await db.execute(
            "SELECT 1 FROM leveling_config_migrations WHERE migration_name=?",
            (LEVELING_CONFIG_BASELINE_MIGRATION,))
        if not await cursor.fetchone():
            # These two baselines are intentionally migrated for every existing
            # guild exactly once. spam_threshold is handled by its own marker
            # below (legacy default 3 -> 10 only; custom values are kept).
            await db.execute("""
                UPDATE leveling_config
                   SET xp_cooldown_seconds = 10,
                       spam_window_seconds = 20,
                       updated_at = CURRENT_TIMESTAMP
            """)
            await db.execute(
                "INSERT INTO leveling_config_migrations (migration_name) VALUES (?)",
                (LEVELING_CONFIG_BASELINE_MIGRATION,))

        cursor = await db.execute(
            "SELECT 1 FROM leveling_config_migrations WHERE migration_name=?",
            (LEVELING_SPAM_THRESHOLD_MIGRATION,))
        if not await cursor.fetchone():
            # 3 was the old schema default, not a deliberate choice, and with
            # the 20s window it would flag ordinary chatting. Only rows still
            # at exactly 3 move to the new default; every other value is kept.
            await db.execute("""
                UPDATE leveling_config
                   SET spam_threshold = 10,
                       updated_at = CURRENT_TIMESTAMP
                 WHERE spam_threshold = 3
            """)
            await db.execute(
                "INSERT INTO leveling_config_migrations (migration_name) VALUES (?)",
                (LEVELING_SPAM_THRESHOLD_MIGRATION,))

        await db.commit()
    except Exception:
        await db.rollback()
        raise


async def init_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)

    async with aiosqlite.connect(DB_PATH) as db:

        # PERFORMANCE FIX (dark-fixes pass #1): every cog/route in this
        # project opens a brand-new aiosqlite connection per query
        # (dozens of call sites, by design). SQLite's default
        # rollback-journal mode serializes ALL readers behind a
        # writer, so under real concurrent load (message XP + voice XP
        # ticks + dashboard requests landing at once) that
        # connection-churn pattern starts throwing "database is
        # locked" errors. WAL mode lets readers proceed while a writer
        # holds the lock — set once here, since WAL IS a persistent,
        # file-level setting: every subsequent connection to this
        # file, bot or dashboard, inherits it.
        #
        # CORRECTION (pass #2 review): busy_timeout, unlike
        # journal_mode, is NOT a persistent file-level setting — it's
        # per-connection. Setting it here only affects this one
        # connection, not the dozens of others opened elsewhere via
        # plain aiosqlite.connect(DB_PATH). This isn't a live bug only
        # because Python's sqlite3 (which aiosqlite wraps) already
        # defaults new connections to a 5-second busy timeout on its
        # own — so those other connections get equivalent behavior by
        # accident, not because of this pragma. Left in place since
        # it's harmless and self-documenting; just don't rely on this
        # line alone if that default ever changes.
        try:
            await db.execute("PRAGMA journal_mode=WAL")
            await db.execute("PRAGMA busy_timeout=5000")
        except Exception as e:
            print(f"[DB] Failed to set WAL mode / busy_timeout: {e}")

        await db.execute("""
            CREATE TABLE IF NOT EXISTS mvp_scores (
                guild_id      INTEGER,
                user_id       INTEGER,
                date          TEXT,
                message_score REAL DEFAULT 0,
                voice_minutes REAL DEFAULT 0,
                total_score   REAL DEFAULT 0,
                PRIMARY KEY (guild_id, user_id, date)
            )
        """)

        # CLEANUP (dark-fixes pass #2): voice_sessions dropped from
        # schema — confirmed zero read/write references anywhere in
        # cogs/ or dashboard/ (only comments referencing the old name
        # remain, e.g. cogs/mvp.py). Superseded entirely by the
        # tick-based activity engine (on_activity_voice_tick), which
        # doesn't need join/leave bookkeeping. Not DROPping the table
        # from any already-deployed DB file here (that's a manual,
        # explicit operator action) — this just stops a fresh DB from
        # ever creating it again.

        await db.execute("""
            CREATE TABLE IF NOT EXISTS activity_stats (
                guild_id          INTEGER,
                user_id           INTEGER,
                date              TEXT,
                messages_count    INTEGER DEFAULT 0,
                words_count       INTEGER DEFAULT 0,
                voice_minutes     REAL DEFAULT 0,
                forum_posts_count INTEGER DEFAULT 0,
                PRIMARY KEY (guild_id, user_id, date)
            )
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_activity_guild
            ON activity_stats(guild_id)
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_activity_guild_date
            ON activity_stats(guild_id, date)
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS levels (
                guild_id INTEGER,
                user_id  INTEGER,
                xp       INTEGER DEFAULT 0,
                level    INTEGER DEFAULT 0,
                PRIMARY KEY (guild_id, user_id)
            )
        """)

        # Phase 5 / Prestige system: prestige tier lives on the same
        # per-member row as xp/level rather than a separate table —
        # it's a third dimension of the same "how far has this member
        # progressed" state, and every existing query that already
        # SELECTs from levels by (guild_id, user_id) only needs one
        # more column, not a join, to also know prestige tier.
        try:
            cursor = await db.execute("PRAGMA table_info(levels)")
            cols = [c[1] for c in await cursor.fetchall()]
            if "prestige" not in cols:
                await db.execute(
                    "ALTER TABLE levels ADD COLUMN prestige INTEGER DEFAULT 0")
                await db.commit()
        except Exception as e:
            print(f"[MIGRATION] levels.prestige: {e}")

        await db.execute("""
            CREATE TABLE IF NOT EXISTS economy (
                guild_id INTEGER,
                user_id  INTEGER,
                balance  INTEGER DEFAULT 0,
                diamonds INTEGER DEFAULT 0,
                PRIMARY KEY (guild_id, user_id)
            )
        """)
        try:
            cursor = await db.execute("PRAGMA table_info(economy)")
            cols = [c[1] for c in await cursor.fetchall()]
            if "diamonds" not in cols:
                await db.execute(
                    "ALTER TABLE economy ADD COLUMN diamonds INTEGER DEFAULT 0")
                await db.commit()
        except Exception as e:
            print(f"[MIGRATION] economy.diamonds: {e}")

        await db.execute("""
            CREATE TABLE IF NOT EXISTS warnings (
                guild_id               INTEGER,
                user_id                INTEGER,
                moderator_id           INTEGER,
                reason                 TEXT,
                timestamp              TEXT,
                user_display_name      TEXT DEFAULT 'Unknown User',
                user_avatar_url        TEXT,
                moderator_display_name TEXT DEFAULT 'Unknown Moderator'
            )
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS tickets (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id      INTEGER,
                channel_id    INTEGER,
                user_id       INTEGER,
                staff_role_id INTEGER,
                status        TEXT DEFAULT 'open',
                category      TEXT,
                claimed_by    INTEGER,
                tags          TEXT,
                created_at    TEXT
            )
        """)

        try:
            cursor = await db.execute("PRAGMA table_info(tickets)")
            cols = [c[1] for c in await cursor.fetchall()]
            if "staff_role_id" not in cols:
                await db.execute(
                    "ALTER TABLE tickets ADD COLUMN staff_role_id INTEGER")
                await db.commit()
        except Exception as e:
            print(f"[MIGRATION] tickets.staff_role_id: {e}")

        # CLEANUP (dark-fixes pass #2): ticket_config dropped from
        # schema — confirmed zero read/write references anywhere (only
        # comments remain, e.g. cogs/tickets.py's P1 #10 fix note).
        # /ticket_setup writes to ticket_settings now; this legacy
        # table was never populated by any current code path. See
        # voice_sessions cleanup note above for the same reasoning re:
        # not touching already-deployed DB files here.

        await db.execute("""
            CREATE TABLE IF NOT EXISTS embed_templates (
                guild_id INTEGER,
                name     TEXT,
                data     TEXT,
                PRIMARY KEY (guild_id, name)
            )
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS reaction_roles (
                guild_id         INTEGER,
                channel_id       INTEGER,
                message_id       INTEGER,
                button_label     TEXT,
                button_emoji     TEXT,
                button_color     TEXT DEFAULT 'blurple',
                role_id          INTEGER,
                booster_only     INTEGER DEFAULT 0,
                required_role_id INTEGER DEFAULT NULL,
                PRIMARY KEY (message_id, role_id)
            )
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS reaction_role_panels (
                message_id           INTEGER PRIMARY KEY,
                guild_id             INTEGER,
                exclusive            INTEGER DEFAULT 0,
                max_roles            INTEGER DEFAULT 0,
                require_confirmation INTEGER DEFAULT 0
            )
        """)

        # PHASE 5 TAIL FIX: message_id added to the key here too,
        # matching database.py's central schema/migration — see
        # that file for the full explanation. This CREATE is a
        # no-op in practice (database.py's init_db() already runs
        # and migrates the table before any cog's on_ready fires),
        # kept only so this cog's own schema doesn't drift from
        # the canonical one if ensure_table() is ever called from
        # a context where init_db() hasn't run yet.
        await db.execute("""
            CREATE TABLE IF NOT EXISTS reaction_role_expiry (
                guild_id   INTEGER,
                user_id    INTEGER,
                role_id    INTEGER,
                message_id INTEGER NOT NULL DEFAULT 0,
                expires_at TEXT,
                PRIMARY KEY (guild_id, user_id, role_id, message_id)
            )
        """)
        try:
            cursor = await db.execute("PRAGMA table_info(reaction_role_expiry)")
            cols = [c[1] for c in await cursor.fetchall()]
            if "message_id" not in cols:
                # Table predates message_id being part of the primary
                # key — SQLite can't ALTER a PK in place, so rebuild.
                # Legacy rows get message_id=0 (best we can do — the
                # panel they belonged to isn't recoverable from the
                # old schema); this only affects expiry rows written
                # before this fix shipped, and worst case is one
                # already-in-flight expiry falling back to "no known
                # panel" instead of being lost.
                await db.execute(
                    "ALTER TABLE reaction_role_expiry "
                    "RENAME TO reaction_role_expiry_old")
                await db.execute("""
                    CREATE TABLE reaction_role_expiry (
                        guild_id   INTEGER,
                        user_id    INTEGER,
                        role_id    INTEGER,
                        message_id INTEGER NOT NULL DEFAULT 0,
                        expires_at TEXT,
                        PRIMARY KEY (guild_id, user_id, role_id, message_id)
                    )
                """)
                await db.execute("""
                    INSERT INTO reaction_role_expiry
                        (guild_id, user_id, role_id, message_id, expires_at)
                    SELECT guild_id, user_id, role_id, 0, expires_at
                    FROM reaction_role_expiry_old
                """)
                await db.execute("DROP TABLE reaction_role_expiry_old")
                await db.commit()
                print("[MIGRATION] reaction_role_expiry rebuilt with "
                      "message_id in primary key")
        except Exception as e:
            print(f"[MIGRATION] reaction_role_expiry.message_id: {e}")

        await db.execute("""
            CREATE TABLE IF NOT EXISTS rr_panels (
                id                   INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id             INTEGER,
                title                TEXT,
                description          TEXT,
                color                TEXT,
                channel_id           TEXT,
                buttons              TEXT,
                exclusive            INTEGER DEFAULT 0,
                max_roles            INTEGER DEFAULT 0,
                require_confirmation INTEGER DEFAULT 0,
                required_role        TEXT
            )
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS custom_commands (
                id                INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id          INTEGER,
                trigger           TEXT,
                allowed_roles     TEXT DEFAULT '[]',
                actions           TEXT DEFAULT '[]',
                embed_title       TEXT,
                embed_description TEXT,
                embed_color       TEXT DEFAULT '#ED4245',
                log_channel_id    INTEGER,
                same_channel      INTEGER DEFAULT 0,
                dm_member         INTEGER DEFAULT 0,
                dm_message        TEXT,
                requires_mention  INTEGER DEFAULT 1,
                requires_reason   INTEGER DEFAULT 0,
                enabled           INTEGER DEFAULT 1,
                created_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS triggers (
                id                INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id          INTEGER,
                trigger_words     TEXT,
                response_text     TEXT,
                response_embed    TEXT,
                response_type     TEXT DEFAULT 'text',
                match_type        TEXT DEFAULT 'contains',
                fuzzy_match       INTEGER DEFAULT 0,
                fuzzy_threshold   INTEGER DEFAULT 80,
                case_sensitive    INTEGER DEFAULT 0,
                response_chance   INTEGER DEFAULT 100,
                cooldown_seconds  INTEGER DEFAULT 0,
                allowed_channels  TEXT,
                enabled           INTEGER DEFAULT 1
            )
        """)

        try:
            cursor = await db.execute("PRAGMA table_info(triggers)")
            cols = [c[1] for c in await cursor.fetchall()]
            if "fuzzy_threshold" not in cols:
                await db.execute(
                    "ALTER TABLE triggers ADD COLUMN fuzzy_threshold INTEGER DEFAULT 80")
            if "cooldown_seconds" not in cols:
                await db.execute(
                    "ALTER TABLE triggers ADD COLUMN cooldown_seconds INTEGER DEFAULT 0")
            await db.commit()
        except Exception as e:
            print(f"[MIGRATION] triggers.fuzzy_threshold/cooldown_seconds: {e}")

        await db.execute("""
            CREATE TABLE IF NOT EXISTS bot_settings (
                key   TEXT PRIMARY KEY,
                value TEXT
            )
        """)

        # CLEANUP (dark-fixes pass #2): disabled_commands dropped from
        # schema — confirmed zero references anywhere. Superseded by
        # command_toggles (see main.py, dashboard/app.py's
        # config_commands route), which is the table actually in use.

        await db.execute("""
            CREATE TABLE IF NOT EXISTS mod_logs (
                id                     INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id               INTEGER,
                action                 TEXT,
                moderator_id           INTEGER,
                target_id              INTEGER,
                reason                 TEXT,
                timestamp              TEXT,
                user_display_name      TEXT DEFAULT 'Unknown User',
                user_avatar_url        TEXT,
                moderator_display_name TEXT DEFAULT 'Unknown Moderator',
                source                 TEXT DEFAULT 'bot',
                extra_actions          TEXT,
                duration_minutes       INTEGER,
                evidence_url           TEXT,
                deleted                INTEGER DEFAULT 0,
                deleted_by             INTEGER,
                deleted_at             TEXT
            )
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS moderation_logs (
                id                     INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id               INTEGER NOT NULL,
                user_id                INTEGER NOT NULL,
                user_display_name      TEXT NOT NULL,
                user_avatar_url        TEXT,
                moderator_id           INTEGER NOT NULL,
                moderator_display_name TEXT NOT NULL,
                action                 TEXT NOT NULL,
                reason                 TEXT,
                source                 TEXT NOT NULL,
                extra_actions          TEXT,
                duration_minutes       INTEGER,
                evidence_url           TEXT,
                expires_at             TIMESTAMP,
                deleted                INTEGER DEFAULT 0,
                deleted_by             INTEGER,
                deleted_at             TIMESTAMP,
                created_at             TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_ml_guild
            ON moderation_logs(guild_id)
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_ml_user
            ON moderation_logs(user_id)
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_ml_date
            ON moderation_logs(created_at)
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS warning_thresholds (
                id               INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id         INTEGER NOT NULL,
                warn_count       INTEGER NOT NULL,
                action           TEXT NOT NULL,
                duration_minutes INTEGER,
                role_id          INTEGER,
                enabled          INTEGER DEFAULT 1,
                created_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_wt_guild
            ON warning_thresholds(guild_id)
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS guild_settings (
                guild_id                 INTEGER PRIMARY KEY,
                prefix                   TEXT DEFAULT '/',
                timezone                 TEXT DEFAULT 'Africa/Cairo',
                language                 TEXT DEFAULT 'en',
                log_channel_id           INTEGER,
                -- Currency DISPLAY config (name + emoji per currency).
                -- Deliberately NULL by default: utils/currency.py is the
                -- one place that decides what a blank value resolves to,
                -- so the defaults live there and nowhere else. See that
                -- module's header — these columns are owned by the
                -- Economy page, and no other file may read or write them.
                currency_name            TEXT,
                coin_emoji_id            TEXT,
                diamond_name             TEXT,
                diamond_emoji_id         TEXT,
                status_rotation_enabled  INTEGER DEFAULT 0,
                status_rotation_interval INTEGER DEFAULT 5,
                updated_at               TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_gs_guild
            ON guild_settings(guild_id)
        """)

        try:
            cursor = await db.execute("PRAGMA table_info(guild_settings)")
            cols = [c[1] for c in await cursor.fetchall()]
            if "diamond_exchange_rate" not in cols:
                await db.execute(
                    "ALTER TABLE guild_settings ADD COLUMN "
                    "diamond_exchange_rate INTEGER DEFAULT 500")
            # Wallet pass (Streak/Inventory phase): currency display
            # metadata is fully configurable (names + emoji icons), so
            # no coin/diamond label or emoji is hardcoded in the UI.
            # `currency_emoji_id` was the pre-Wallet primary-currency icon
            # column; it was superseded by `coin_emoji_id`. These four
            # columns are read and written ONLY through utils/currency.py —
            # see that module's header for why currency display config
            # lives here but is owned by the Economy page.
            # These ALTERs deliberately add the columns with NO DEFAULT.
            # "Unset" must be NULL, not a copy of the default string:
            # utils/currency.py is the single source of truth for what a
            # blank value resolves to (its DEFAULT_* constants), and it
            # already treats NULL/'' as unset. Baking 'Coins'/'🪙' into a
            # column default would (a) put the defaults in a second place
            # that can drift from the resolver, and (b) make "never
            # configured" indistinguishable from "configured to the
            # default" — which is exactly what the carry-over below needs
            # to tell apart. `currency_name` is added here too so an older
            # database missing that column self-heals the same way the
            # other three already did.
            added_coin_emoji = "coin_emoji_id" not in cols
            if "currency_name" not in cols:
                await db.execute(
                    "ALTER TABLE guild_settings ADD COLUMN "
                    "currency_name TEXT")
            if added_coin_emoji:
                await db.execute(
                    "ALTER TABLE guild_settings ADD COLUMN "
                    "coin_emoji_id TEXT")
            if "diamond_name" not in cols:
                await db.execute(
                    "ALTER TABLE guild_settings ADD COLUMN "
                    "diamond_name TEXT")
            if "diamond_emoji_id" not in cols:
                await db.execute(
                    "ALTER TABLE guild_settings ADD COLUMN "
                    "diamond_emoji_id TEXT")
            await db.commit()

            # One-time carry-over for guilds that configured a primary
            # currency icon BEFORE the column split. On those databases
            # `currency_emoji_id` holds the only icon the owner ever set,
            # and the freshly-added `coin_emoji_id` is NULL for every
            # existing row. Copy the value across so the admin's icon
            # survives instead of silently reverting to the default.
            #
            # The copy is gated on `added_coin_emoji`, so it runs only on
            # the one init_db() that actually creates the column — it can
            # never re-fire later and overwrite an icon an admin set
            # deliberately through the Economy page (including deliberately
            # choosing the default). The NULL-only WHERE is a second
            # belt-and-braces guard for the same thing.
            #
            # The legacy column is deliberately NOT dropped — this
            # project's established rule is never to DROP a column on an
            # already-deployed SQLite file (see the ticket_config /
            # voice_sessions cleanup notes earlier in this file).
            if added_coin_emoji and "currency_emoji_id" in cols:
                cursor = await db.execute("""
                    UPDATE guild_settings
                       SET coin_emoji_id = currency_emoji_id
                     WHERE currency_emoji_id IS NOT NULL
                       AND trim(currency_emoji_id) <> ''
                       AND (coin_emoji_id IS NULL
                            OR trim(coin_emoji_id) = '')
                """)
                await db.commit()
                if cursor.rowcount:
                    print(f"[MIGRATION] carried over legacy currency icon "
                          f"for {cursor.rowcount} guild(s) "
                          f"(currency_emoji_id -> coin_emoji_id)")
        except Exception as e:
            print(f"[MIGRATION] guild_settings currency columns: {e}")

        # Cairo canonical: normalize legacy UTC / Asia/Cairo to Africa/Cairo
        try:
            await db.execute("UPDATE guild_settings SET timezone='Africa/Cairo' WHERE timezone IN ('UTC','Etc/UTC','Asia/Cairo')")
            await db.execute("UPDATE guild_settings SET timezone='Africa/Cairo' WHERE timezone IS NULL OR trim(timezone)=''")
            await db.commit()
        except Exception as e:
            print(f"[MIGRATION] timezone normalization: {e}")

        await db.execute("""
            CREATE TABLE IF NOT EXISTS guild_settings_kv (
                guild_id   INTEGER NOT NULL,
                key        TEXT NOT NULL,
                value      TEXT,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (guild_id, key)
            )
        """)

        # Per-server bot profile: nickname, avatar, banner, and bio are
        # ALL genuinely per-guild via Discord's "Modify Current Member"
        # endpoint (PATCH /guilds/{id}/members/@me — see
        # utils/bot_profile.py's header for the confirmed field list).
        # Nothing here is cosmetic-only; this is what Discord's own
        # client shows for the bot in THIS server, and nowhere else.
        await db.execute("""
            CREATE TABLE IF NOT EXISTS guild_bot_profile (
                guild_id   INTEGER PRIMARY KEY,
                nickname   TEXT,
                avatar_url TEXT,
                banner_url TEXT,
                bio        TEXT,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        try:
            cursor = await db.execute("PRAGMA table_info(guild_bot_profile)")
            cols = [c[1] for c in await cursor.fetchall()]
            if "banner_url" not in cols:
                await db.execute(
                    "ALTER TABLE guild_bot_profile ADD COLUMN banner_url TEXT")
            if "bio" not in cols:
                await db.execute(
                    "ALTER TABLE guild_bot_profile ADD COLUMN bio TEXT")
            await db.commit()
        except Exception as e:
            print(f"[MIGRATION] guild_bot_profile.banner_url/bio: {e}")

        await db.execute("""
            CREATE TABLE IF NOT EXISTS status_messages (
                id       INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id INTEGER NOT NULL,
                text     TEXT NOT NULL,
                type     TEXT DEFAULT 'playing',
                position INTEGER DEFAULT 0,
                enabled  INTEGER DEFAULT 1
            )
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS welcome_config (
                guild_id          INTEGER PRIMARY KEY,
                join_enabled      INTEGER DEFAULT 0,
                join_channel_id   INTEGER,
                auto_role_id      INTEGER,
                join_message_mode TEXT DEFAULT 'random',
                leave_enabled     INTEGER DEFAULT 0,
                leave_channel_id  INTEGER,
                rules_enabled     INTEGER DEFAULT 0,
                rules_channel_id  INTEGER,
                rules_role_id     INTEGER,
                rules_button_text TEXT DEFAULT '✅ I Accept',
                updated_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS welcome_messages (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id   INTEGER NOT NULL,
                type       TEXT NOT NULL,
                embed_data TEXT NOT NULL,
                position   INTEGER DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_wm_guild
            ON welcome_messages(guild_id)
        """)

        # Run the Leveling config schema/data migration transactionally. The
        # helper is idempotent for schema work and marker-gated for baseline
        # updates, so startup never re-applies defaults over Dashboard choices.
        await db.commit()
        await migrate_leveling_config(db)

        # Persistent one-hour anti-spam budget. Each incident deduction is
        # recorded atomically with levels.xp by apply_spam_penalty(), so an
        # in-memory/cog restart cannot reset the cumulative limit.
        await db.execute("""
            CREATE TABLE IF NOT EXISTS leveling_spam_penalty_events (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id    INTEGER NOT NULL,
                user_id     INTEGER NOT NULL,
                created_at  REAL NOT NULL,
                deducted    INTEGER NOT NULL CHECK (deducted > 0),
                rolling_cap INTEGER NOT NULL CHECK (rolling_cap >= 0)
            )
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_leveling_spam_penalties_member_time
            ON leveling_spam_penalty_events(guild_id, user_id, created_at)
        """)

        # Persist the active spam episode separately from the in-memory
        # detector's short-lived message history. One row per member retains
        # the current incident, its quiet-window deadline, the one-time
        # penalty/warning claims, and the last-warning time across restarts.
        await db.execute("""
            CREATE TABLE IF NOT EXISTS leveling_spam_incidents (
                guild_id          INTEGER NOT NULL,
                user_id           INTEGER NOT NULL,
                incident_id       TEXT NOT NULL,
                active_until      REAL NOT NULL,
                penalty_attempted INTEGER NOT NULL DEFAULT 0,
                warning_attempted INTEGER NOT NULL DEFAULT 0,
                last_warning_at   REAL,
                PRIMARY KEY (guild_id, user_id)
            )
        """)

        # Existing penalty ledgers predate incident ids. SQLite cannot add
        # this column conditionally in CREATE TABLE, so migrate it in place;
        # legacy budget rows remain valid with a NULL incident_id.
        cursor = await db.execute(
            "PRAGMA table_info(leveling_spam_penalty_events)")
        penalty_columns = {row[1] for row in await cursor.fetchall()}
        if "incident_id" not in penalty_columns:
            await db.execute(
                "ALTER TABLE leveling_spam_penalty_events "
                "ADD COLUMN incident_id TEXT")
        await db.execute("""
            CREATE UNIQUE INDEX IF NOT EXISTS
                idx_leveling_spam_penalties_incident
            ON leveling_spam_penalty_events(guild_id, user_id, incident_id)
            WHERE incident_id IS NOT NULL
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS leveling_rewards (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id   INTEGER NOT NULL,
                level      INTEGER NOT NULL,
                role_id    INTEGER NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_lr_guild
            ON leveling_rewards(guild_id)
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS leveling_currency_rewards (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id   INTEGER NOT NULL,
                level      INTEGER NOT NULL,
                currency   TEXT NOT NULL DEFAULT 'balance',
                amount     INTEGER NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_lcr_guild
            ON leveling_currency_rewards(guild_id)
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS leveling_shop_rewards (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id   INTEGER NOT NULL,
                level      INTEGER NOT NULL,
                item_id    INTEGER NOT NULL,
                quantity   INTEGER NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(guild_id, level, item_id)
            )
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_lsr_guild
            ON leveling_shop_rewards(guild_id)
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS leveling_boost_rewards (
                id             INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id       INTEGER NOT NULL,
                level          INTEGER NOT NULL,
                multiplier     REAL NOT NULL,
                duration_hours INTEGER NOT NULL,
                created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE (guild_id, level)
            )
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_leveling_boost_rewards_guild
            ON leveling_boost_rewards(guild_id)
        """)

        # Booster-only level rewards: 'everyone' (default, every existing row)
        # or 'boosters'. Idempotent in-place migration; XP-boost rewards are
        # deliberately not included.
        for _reward_table in ("leveling_rewards", "leveling_currency_rewards",
                              "leveling_shop_rewards"):
            cursor = await db.execute(f"PRAGMA table_info({_reward_table})")
            _reward_columns = {row[1] for row in await cursor.fetchall()}
            if "audience" not in _reward_columns:
                await db.execute(
                    f"ALTER TABLE {_reward_table} "
                    "ADD COLUMN audience TEXT NOT NULL DEFAULT 'everyone'")

        await db.execute("""
            CREATE TABLE IF NOT EXISTS leveling_reset_config (
                guild_id   INTEGER PRIMARY KEY,
                enabled    INTEGER DEFAULT 0,
                period     TEXT DEFAULT 'weekly',
                last_reset TIMESTAMP
            )
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS leveling_leaderboard_history (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id     INTEGER NOT NULL,
                user_id      INTEGER NOT NULL,
                xp           INTEGER NOT NULL,
                level        INTEGER NOT NULL,
                rank         INTEGER NOT NULL,
                period       TEXT NOT NULL,
                period_end   TIMESTAMP NOT NULL,
                created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_llh_guild
            ON leveling_leaderboard_history(guild_id, period_end)
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS leveling_active_boosts (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id   INTEGER NOT NULL,
                user_id    INTEGER NOT NULL,
                multiplier REAL NOT NULL,
                expires_at TIMESTAMP NOT NULL,
                source     TEXT DEFAULT 'shop',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_lab_guild_user
            ON leveling_active_boosts(guild_id, user_id)
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_lab_expires
            ON leveling_active_boosts(expires_at)
        """)
        # Level-claim boosts only. Shop and potion rows use other source
        # values, so this index does not limit those inserts.
        await db.execute("""
            CREATE UNIQUE INDEX IF NOT EXISTS idx_lab_level_claim_source
            ON leveling_active_boosts(source)
            WHERE source LIKE 'level_claim:%'
        """)

        # Daily / Streak (persisted): replaces the old in-memory
        # _daily_cooldowns dict in cogs/economy.py, which did not
        # survive a bot restart and had no concept of a streak at
        # all. last_claim_date is stored as a Cairo calendar date
        # string ('YYYY-MM-DD', Africa/Cairo) rather than a timestamp
        # specifically so "same day / previous day / missed a day" is a
        # plain string comparison in utils/daily_engine.py, with zero
        # timezone ambiguity. Storage is Cairo date, not UTC. One row per (guild_id, user_id); the
        # claim-check-and-write against this table runs inside a
        # single BEGIN IMMEDIATE transaction (see daily_engine.py) so
        # a double-click or two concurrent /daily invocations can't
        # both succeed.
        await db.execute("""
            CREATE TABLE IF NOT EXISTS daily_claims (
                guild_id        INTEGER NOT NULL,
                user_id         INTEGER NOT NULL,
                last_claim_date TEXT NOT NULL,
                streak_count    INTEGER NOT NULL DEFAULT 1,
                last_claimed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (guild_id, user_id)
            )
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS leveling_bonus_roles (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id   INTEGER NOT NULL,
                role_id    INTEGER NOT NULL,
                multiplier REAL DEFAULT 1.5,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_lbr_guild
            ON leveling_bonus_roles(guild_id)
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS leveling_blacklist_roles (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id   INTEGER NOT NULL,
                role_id    INTEGER NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Phase 5 / Prestige system. One config row per guild
        # (min_level gate + on/off), plus one row per (guild, tier)
        # mapping a prestige tier number to the Discord role granted
        # for reaching it. Mirrors leveling_rewards' shape (a small
        # per-guild CRUD table of level/tier -> role_id) rather than
        # inventing a new pattern.
        await db.execute("""
            CREATE TABLE IF NOT EXISTS prestige_config (
                guild_id   INTEGER PRIMARY KEY,
                enabled    INTEGER DEFAULT 1,
                min_level  INTEGER DEFAULT 50,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS prestige_roles (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id   INTEGER NOT NULL,
                tier       INTEGER NOT NULL,
                role_id    INTEGER NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(guild_id, tier)
            )
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_pr_guild
            ON prestige_roles(guild_id)
        """)

        # The finalized Prestige system (replaces the old XP/level-gated
        # reset mechanic): the per-tier currency multipliers live here.
        # One row per (guild, tier 1..6). Rows are seeded lazily to the
        # locked defaults on first read (see utils/prestige.py), so a
        # fresh install gets a complete, valid config without an admin
        # having to touch the dashboard first. Purely additive; existing
        # games/servers are unaffected.
        await db.execute("""
            CREATE TABLE IF NOT EXISTS prestige_tiers (
                guild_id           INTEGER NOT NULL,
                tier               INTEGER NOT NULL,
                coins_multiplier   REAL DEFAULT 1.0,
                diamonds_multiplier REAL DEFAULT 1.0,
                PRIMARY KEY (guild_id, tier)
            )
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_pt_guild
            ON prestige_tiers(guild_id)
        """)

        # Booster-only Prestige VI shop activation. Permanent prestige
        # stays I-V on levels.prestige; this table only records that the
        # member activated the VI shop entry. Effective VI additionally
        # requires an active boost at read time (utils/prestige.py).
        await db.execute("""
            CREATE TABLE IF NOT EXISTS prestige_vi_activations (
                guild_id   INTEGER NOT NULL,
                user_id    INTEGER NOT NULL,
                activated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (guild_id, user_id)
            )
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS mvp_config (
                guild_id            INTEGER PRIMARY KEY,
                mvp_role_id         INTEGER,
                announce_channel_id INTEGER,
                reset_hours         INTEGER DEFAULT 24,
                enabled             INTEGER DEFAULT 1,
                cycle_hours         INTEGER DEFAULT 6,
                chat_word_weight    REAL DEFAULT 1.0,
                voice_minute_weight REAL DEFAULT 2.0,
                daily_reset_hour    INTEGER DEFAULT 0
            )
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS mvp_history (
                id                INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id          INTEGER NOT NULL,
                user_id           INTEGER NOT NULL,
                user_display_name TEXT NOT NULL,
                cycle_start       TIMESTAMP NOT NULL,
                cycle_end         TIMESTAMP NOT NULL,
                score             INTEGER NOT NULL,
                created_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_mvph_guild
            ON mvp_history(guild_id)
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS boost_config (
                guild_id               INTEGER PRIMARY KEY,
                enabled                INTEGER DEFAULT 1,
                boost1_role_id         INTEGER,
                boost2_role_id         INTEGER,
                boost2_channel_id      INTEGER,
                color_roles_enabled    INTEGER DEFAULT 0,
                auto_remove_on_unboost INTEGER DEFAULT 1
            )
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS boost_color_roles (
                id                   INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id             INTEGER NOT NULL,
                role_id              INTEGER NOT NULL,
                role_name            TEXT NOT NULL,
                requires_boost_level INTEGER DEFAULT 2,
                created_at           TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS shop_items (
                id               INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id         INTEGER NOT NULL,
                name             TEXT NOT NULL,
                description      TEXT,
                price            INTEGER NOT NULL,
                type             TEXT NOT NULL,
                role_id          INTEGER,
                duration_hours   INTEGER,
                show_button      INTEGER DEFAULT 1,
                limited          INTEGER DEFAULT 0,
                limited_until    TIMESTAMP,
                max_stock        INTEGER,
                current_stock    INTEGER,
                featured         INTEGER DEFAULT 0,
                required_level   INTEGER DEFAULT 0,
                required_role_id INTEGER,
                enabled          INTEGER DEFAULT 1,
                created_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_si_guild
            ON shop_items(guild_id)
        """)

        try:
            cursor = await db.execute("PRAGMA table_info(shop_items)")
            cols = [c[1] for c in await cursor.fetchall()]
            if "price_diamonds" not in cols:
                await db.execute(
                    "ALTER TABLE shop_items ADD COLUMN "
                    "price_diamonds INTEGER DEFAULT NULL")
                await db.commit()
        except Exception as e:
            print(f"[MIGRATION] shop_items.price_diamonds: {e}")

        try:
            cursor = await db.execute("PRAGMA table_info(shop_items)")
            cols = [c[1] for c in await cursor.fetchall()]
            if "xp_boost_multiplier" not in cols:
                await db.execute(
                    "ALTER TABLE shop_items ADD COLUMN "
                    "xp_boost_multiplier REAL DEFAULT NULL")
                await db.commit()
        except Exception as e:
            print(f"[MIGRATION] shop_items.xp_boost_multiplier: {e}")

        # Finalized Prestige system: shop items of type='prestige' carry
        # the permanent tier (1..5) they grant. NULL for every other item
        # type, so existing shop items are unchanged. Prestige is NOT an
        # inventory item and is never delivered via the reward engine.
        try:
            cursor = await db.execute("PRAGMA table_info(shop_items)")
            cols = [c[1] for c in await cursor.fetchall()]
            if "prestige_tier" not in cols:
                await db.execute(
                    "ALTER TABLE shop_items ADD COLUMN "
                    "prestige_tier INTEGER DEFAULT NULL")
                await db.commit()
        except Exception as e:
            print(f"[MIGRATION] shop_items.prestige_tier: {e}")

        # Rank Card foundation (item catalog / rarity / equip system,
        # pass 1 — schema + backend). shop_items gets two new,
        # optional admin-set fields: icon_url (shown on the future
        # /rank card's item grid + equipped-role slot) and rarity
        # (Common/Rare/Epic/Legendary/Mythical/Secret — the PRIMARY
        # sort key for that grid, locked with Dark; price is only a
        # tiebreaker within the same rarity, since minigame/event/
        # mission drops are often "free" and rarity is the only
        # signal that makes those sort sensibly against purchased
        # items). Both nullable/defaulted so every existing shop item
        # keeps working unchanged (rarity='common', icon_url=NULL —
        # renders with no icon, sorts at the bottom of its price
        # bracket, same as before this migration ran).
        try:
            cursor = await db.execute("PRAGMA table_info(shop_items)")
            cols = [c[1] for c in await cursor.fetchall()]
            if "icon_url" not in cols:
                await db.execute(
                    "ALTER TABLE shop_items ADD COLUMN icon_url TEXT")
            if "rarity" not in cols:
                await db.execute(
                    "ALTER TABLE shop_items ADD COLUMN "
                    "rarity TEXT DEFAULT 'common'")
            await db.commit()
        except Exception as e:
            print(f"[MIGRATION] shop_items.icon_url/rarity: {e}")

        # Shop Publisher Step 1 (Slice 1): flat, guild-scoped presentation
        # categories. shop_categories holds NO commerce data (no price/
        # stock/duration/type) and shop_items.category_id is the ONLY link
        # between a product and its category — membership is presentation
        # metadata and NEVER implies publication. Nullable and never a
        # foreign key (this schema has none); deleting a category NULLs the
        # links (dashboard/api/shop_categories.py). V1 is flat: one category
        # per product, no hierarchy, no multi-category.
        await db.execute("""
            CREATE TABLE IF NOT EXISTS shop_categories (
                id                INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id          INTEGER NOT NULL,
                name              TEXT NOT NULL,
                emoji             TEXT DEFAULT '🎫',
                enabled           INTEGER DEFAULT 1,
                sort_order        INTEGER DEFAULT 0,
                created_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_sc_guild
            ON shop_categories(guild_id)
        """)

        # Design Draft Persistence: saved Shop Designer drafts. Orchestration/
        # presentation configuration ONLY — never commerce truth (shop_items
        # stays the source), never category data, never resolved output or
        # publication state. design_json holds the Step 0 Design draft
        # {presentation, products, action}; its presentation is the design's
        # own snapshot (normalized at save) and source_template_name is
        # provenance only — never dereferenced after save. Hard-delete MVP;
        # no revisions or version history.
        await db.execute("""
            CREATE TABLE IF NOT EXISTS shop_designs (
                id                   INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id             INTEGER NOT NULL,
                name                 TEXT NOT NULL,
                source_template_name TEXT,
                design_json          TEXT NOT NULL,
                created_at           TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at           TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_sd_guild
            ON shop_designs(guild_id)
        """)

        # Explicit Shop product-emoji preparation. Assets are application-wide
        # and keyed by final uploaded bytes; aliases remain guild/URL scoped.
        # Schema is centralized here, never created lazily by preview readers.
        from utils.shop_emoji import ensure_shop_emoji_schema
        await ensure_shop_emoji_schema(db)

        # Timed ownership + the Shop purchase journal. Additive by design:
        # `inventory_items` keeps its UNIQUE(guild, user, item_name) contract
        # (trade, reward provenance and reversal all rely on it), so temporary
        # holdings live beside it rather than re-keying it.
        from utils.timed_ownership import (
            ensure_timed_ownership_schema, ensure_purchase_journal_schema,
        )
        await ensure_timed_ownership_schema(db)
        await ensure_purchase_journal_schema(db)

        # Publication identity/state only. The live message is always rebuilt
        # from shop_designs + current shop_items; never persist commerce or
        # rendered payload snapshots here. No Design/channel uniqueness:
        # each explicit Publish creates a separate association.
        await db.execute("""
            CREATE TABLE IF NOT EXISTS shop_publications (
                id                  INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id            INTEGER NOT NULL,
                design_id           INTEGER NOT NULL,
                channel_id          INTEGER NOT NULL,
                message_id          INTEGER,
                status              TEXT NOT NULL DEFAULT 'pending',
                last_error          TEXT,
                created_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_published_at   TIMESTAMP
            )
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_sp_guild_design
            ON shop_publications(guild_id, design_id)
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_sp_guild_channel
            ON shop_publications(guild_id, channel_id)
        """)

        try:
            cursor = await db.execute("PRAGMA table_info(shop_items)")
            cols = [c[1] for c in await cursor.fetchall()]
            if "category_id" not in cols:
                await db.execute(
                    "ALTER TABLE shop_items ADD COLUMN "
                    "category_id INTEGER")
                await db.commit()
        except Exception as e:
            print(f"[MIGRATION] shop_items.category_id: {e}")

        # Shop Designer Step 1: explicit one-level product family. Existing
        # rows remain roots (NULL); names are never used to infer options.
        # Triggers enforce the relationship because SQLite foreign-key
        # enforcement is connection-local and existing callers do not all
        # enable PRAGMA foreign_keys.
        cursor = await db.execute("PRAGMA table_info(shop_items)")
        cols = [c[1] for c in await cursor.fetchall()]
        if "option_of_id" not in cols:
            await db.execute(
                "ALTER TABLE shop_items ADD COLUMN "
                "option_of_id INTEGER DEFAULT NULL")
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_si_guild_option
            ON shop_items(guild_id, option_of_id)
        """)
        await db.execute("""
            CREATE TRIGGER IF NOT EXISTS shop_item_option_insert_guard
            BEFORE INSERT ON shop_items
            WHEN NEW.option_of_id IS NOT NULL
            BEGIN
                SELECT CASE WHEN NOT EXISTS (
                    SELECT 1 FROM shop_items p
                    WHERE p.id = NEW.option_of_id
                      AND p.guild_id = NEW.guild_id
                      AND p.option_of_id IS NULL
                ) THEN RAISE(ABORT, 'option parent must be a same-guild root') END;
            END
        """)
        await db.execute("""
            CREATE TRIGGER IF NOT EXISTS shop_item_option_update_guard
            BEFORE UPDATE OF id, option_of_id, guild_id ON shop_items
            BEGIN
                SELECT CASE WHEN NEW.option_of_id IS NOT NULL AND NOT EXISTS (
                    SELECT 1 FROM shop_items p
                    WHERE p.id = NEW.option_of_id
                      AND p.id != NEW.id
                      AND p.guild_id = NEW.guild_id
                      AND p.option_of_id IS NULL
                ) THEN RAISE(ABORT, 'option parent must be a different same-guild root') END;
                SELECT CASE WHEN NEW.option_of_id IS NOT NULL AND EXISTS (
                    SELECT 1 FROM shop_items child
                    WHERE child.option_of_id = OLD.id
                ) THEN RAISE(ABORT, 'a product with options cannot become an option') END;
                SELECT CASE WHEN NEW.id != OLD.id AND EXISTS (
                    SELECT 1 FROM shop_items child
                    WHERE child.option_of_id = OLD.id
                ) THEN RAISE(ABORT, 'a root with options cannot change id') END;
                SELECT CASE WHEN NEW.guild_id != OLD.guild_id AND EXISTS (
                    SELECT 1 FROM shop_items child
                    WHERE child.option_of_id = OLD.id
                ) THEN RAISE(ABORT, 'a root with options cannot change guild') END;
            END
        """)
        await db.execute("""
            CREATE TRIGGER IF NOT EXISTS shop_item_option_delete_guard
            BEFORE DELETE ON shop_items
            WHEN EXISTS (
                SELECT 1 FROM shop_items child
                WHERE child.option_of_id = OLD.id
            )
            BEGIN
                SELECT RAISE(ABORT, 'root products with options cannot be deleted');
            END
        """)
        await db.commit()

        # Rank Card foundation: item_catalog is the single, source-
        # agnostic place the future card renderer (and /inventory)
        # resolve an item's icon/rarity/value from — keyed by
        # (guild_id, item_name), NOT by shop_items.id, matching how
        # inventory_items already references items purely by name
        # (a purchased item's inventory row already survives the shop
        # listing being edited/deleted; this follows the same loose
        # coupling). Auto-populated whenever a shop item is saved
        # (see dashboard/api/economy_shop.py); items granted only via
        # events/minigames/missions simply have no row here yet and
        # fall back to rarity='common', no icon — a deliberate,
        # documented gap (no admin UI for that yet, per Dark: "not
        # now"), not an oversight.
        await db.execute("""
            CREATE TABLE IF NOT EXISTS item_catalog (
                id             INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id       INTEGER NOT NULL,
                item_name      TEXT NOT NULL,
                icon_url       TEXT,
                rarity         TEXT NOT NULL DEFAULT 'common',
                value_currency TEXT,
                value_amount   INTEGER,
                updated_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(guild_id, item_name)
            )
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_ic_guild
            ON item_catalog(guild_id)
        """)

        # Rank Card foundation: equipped_roles tracks, per member, the
        # ONE role/temp_role-type inventory item currently "worn" —
        # single row per (guild_id, user_id) by design (PK enforces
        # it), since only one purchased/won cosmetic role can be
        # equipped at a time (locked with Dark: equipping swaps the
        # actual Discord role, doesn't just relabel something).
        # Materialized here rather than derived by scanning
        # member.roles at read time, matching how the rest of this
        # project caches live-ish state in the DB instead of
        # re-deriving it from Discord on every read (twitch_config.
        # is_live, youtube_config.live_video_id, etc).
        await db.execute("""
            CREATE TABLE IF NOT EXISTS equipped_roles (
                guild_id    INTEGER NOT NULL,
                user_id     INTEGER NOT NULL,
                item_name   TEXT NOT NULL,
                role_id     INTEGER NOT NULL,
                entry_key   TEXT,
                equipped_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (guild_id, user_id)
            )
        """)
        # Timed ownership: the single equip slot must be able to say WHICH
        # ownership record it is wearing. `item_name` cannot — a permanent and
        # a timed "Ocean Blue" share it. Additive and idempotent; NULL on
        # pre-existing rows, which `get_equipped()` reads as "legacy permanent
        # ownership, match by name".
        cursor = await db.execute("PRAGMA table_info(equipped_roles)")
        if "entry_key" not in {c[1] for c in await cursor.fetchall()}:
            try:
                await db.execute(
                    "ALTER TABLE equipped_roles ADD COLUMN entry_key TEXT")
            except Exception as e:
                print(f"[MIGRATION] equipped_roles.entry_key: {e}")

        # Wallet pass: equipped_titles is the Title equip slot. It is a
        # SEPARATE table from equipped_roles on purpose — the locked
        # project decision is that the Title slot is independent from
        # the Discord Role slot (a member wears one of each, and
        # equipping a title must never disturb an equipped role).
        # equipped_roles couldn't have carried it: its PK is
        # (guild_id, user_id) with a NOT NULL role_id, so a title would
        # have had to fake a role_id or force that constraint to be
        # relaxed, weakening the single-role invariant it exists to
        # protect. Same shape (one row per member = at most one
        # equipped title), zero impact on existing rows. Ownership
        # still lives in inventory_items (item_type='title'); this
        # table only records WHICH owned title is worn — see
        # utils/title_engine.py.
        await db.execute("""
            CREATE TABLE IF NOT EXISTS equipped_titles (
                guild_id    INTEGER NOT NULL,
                user_id     INTEGER NOT NULL,
                item_name   TEXT NOT NULL,
                equipped_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (guild_id, user_id)
            )
        """)

        # Wallet pass: a shop item of type='potion' is a CONSUMABLE that
        # lands in the buyer's inventory and applies its effect only
        # when used, unlike type='xp_boost' which fires immediately at
        # purchase and never reaches inventory. It reuses the existing
        # xp_boost_multiplier + duration_hours columns for its effect
        # parameters, so no new columns were needed at all — this
        # comment exists to record that reuse rather than to document a
        # migration. type='title' likewise needs no new column: a title
        # is name + icon + rarity, all of which shop_items already has.
        await db.execute("""
            CREATE TABLE IF NOT EXISTS purchase_history (
                id                INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id          INTEGER NOT NULL,
                user_id           INTEGER NOT NULL,
                user_display_name TEXT NOT NULL,
                item_id           INTEGER NOT NULL,
                item_name         TEXT NOT NULL,
                price_paid        INTEGER NOT NULL,
                purchased_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                expires_at        TIMESTAMP
            )
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_ph_guild
            ON purchase_history(guild_id)
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_ph_user
            ON purchase_history(user_id)
        """)

        try:
            cursor = await db.execute("PRAGMA table_info(purchase_history)")
            cols = [c[1] for c in await cursor.fetchall()]
            if "currency_paid" not in cols:
                await db.execute(
                    "ALTER TABLE purchase_history ADD COLUMN "
                    "currency_paid TEXT DEFAULT 'balance'")
                await db.commit()
        except Exception as e:
            print(f"[MIGRATION] purchase_history.currency_paid: {e}")

        await db.execute("""
            CREATE TABLE IF NOT EXISTS temp_roles (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id    INTEGER NOT NULL,
                user_id     INTEGER NOT NULL,
                role_id     INTEGER NOT NULL,
                assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                expires_at  TIMESTAMP NOT NULL,
                source      TEXT DEFAULT 'shop'
            )
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_tr_expires
            ON temp_roles(expires_at)
        """)
        # Level-claim temp-role units. Shop purchases leave both columns
        # NULL, so their inserts and the expiry cleanup are unchanged.
        # A partial unique index lets a claim retry see units it already
        # wrote without blocking those NULL shop rows.
        try:
            cursor = await db.execute("PRAGMA table_info(temp_roles)")
            cols = [c[1] for c in await cursor.fetchall()]
            if "claim_id" not in cols:
                await db.execute(
                    "ALTER TABLE temp_roles ADD COLUMN claim_id INTEGER")
            if "unit_index" not in cols:
                await db.execute(
                    "ALTER TABLE temp_roles ADD COLUMN unit_index INTEGER")
            await db.execute("""
                CREATE UNIQUE INDEX IF NOT EXISTS idx_temp_roles_claim_unit
                ON temp_roles(claim_id, unit_index)
                WHERE claim_id IS NOT NULL
            """)
            await db.commit()
        except Exception as e:
            print(f"[MIGRATION] temp_roles.claim_id: {e}")

        await db.execute("""
            CREATE TABLE IF NOT EXISTS transaction_ledger (
                id               INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id         INTEGER NOT NULL,
                user_id          INTEGER NOT NULL,
                currency         TEXT NOT NULL,
                amount           INTEGER NOT NULL,
                balance_after    INTEGER,
                type             TEXT NOT NULL,
                reason           TEXT,
                source           TEXT DEFAULT 'system',
                related_user_id  INTEGER,
                reversed         INTEGER DEFAULT 0,
                reversed_at      TIMESTAMP,
                reversed_by      INTEGER,
                created_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_tl_guild
            ON transaction_ledger(guild_id)
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_tl_guild_user
            ON transaction_ledger(guild_id, user_id)
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_tl_date
            ON transaction_ledger(created_at)
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS inventory_items (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id   INTEGER NOT NULL,
                user_id    INTEGER NOT NULL,
                item_name  TEXT NOT NULL,
                item_type  TEXT DEFAULT 'custom',
                quantity   INTEGER NOT NULL DEFAULT 0,
                metadata   TEXT,
                source     TEXT DEFAULT 'system',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(guild_id, user_id, item_name)
            )
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_inv_guild_user
            ON inventory_items(guild_id, user_id)
        """)

        # Level/reward provenance, operation journal and the per-member
        # coordination lease (utils/level_ops.py). Created here so a normal boot
        # has them, and created lazily by level_ops.ensure_tables() for a
        # database that predates them.
        from utils.level_ops import SCHEMA as LEVEL_OPS_SCHEMA
        for _statement in LEVEL_OPS_SCHEMA:
            await db.execute(_statement)
        await db.commit()

        await db.execute("""
            CREATE TABLE IF NOT EXISTS temp_bans (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id    INTEGER NOT NULL,
                user_id     INTEGER NOT NULL,
                banned_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                expires_at  TIMESTAMP NOT NULL,
                reason      TEXT,
                source      TEXT DEFAULT 'auto-threshold'
            )
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_tb_expires
            ON temp_bans(expires_at)
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_tb_guild_user
            ON temp_bans(guild_id, user_id)
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS events (
                id                    INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id              INTEGER NOT NULL,
                title                 TEXT NOT NULL,
                description           TEXT,
                type                  TEXT NOT NULL,
                reward_type           TEXT NOT NULL,
                reward_value          TEXT NOT NULL,
                reward_duration_hours INTEGER,
                max_winners           INTEGER DEFAULT 3,
                channel_id            INTEGER,
                schedule_type         TEXT DEFAULT 'manual',
                schedule_time         TIMESTAMP,
                random_min_hours      INTEGER,
                random_max_hours      INTEGER,
                embed_data            TEXT,
                enabled               INTEGER DEFAULT 1,
                created_at            TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_ev_guild
            ON events(guild_id)
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS event_winners (
                id                INTEGER PRIMARY KEY AUTOINCREMENT,
                event_id          INTEGER NOT NULL,
                guild_id          INTEGER NOT NULL,
                user_id           INTEGER NOT NULL,
                user_display_name TEXT NOT NULL,
                won_at            TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS youtube_config (
                id                  INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id            INTEGER NOT NULL,
                youtube_channel_url TEXT NOT NULL,
                youtube_channel_id  TEXT,
                discord_channel_id  INTEGER NOT NULL,
                custom_message      TEXT,
                embed_data          TEXT,
                ping_role_id        INTEGER,
                check_interval_min  INTEGER DEFAULT 10,
                last_video_id       TEXT,
                enabled             INTEGER DEFAULT 1,
                created_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS twitch_config (
                id                  INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id            INTEGER NOT NULL,
                twitch_username     TEXT NOT NULL,
                discord_channel_id  INTEGER NOT NULL,
                custom_message      TEXT DEFAULT '🔴 {streamer} is LIVE!',
                embed_data          TEXT,
                ping_role_id        INTEGER,
                give_role_id        INTEGER,
                role_duration_hours INTEGER,
                is_live             INTEGER DEFAULT 0,
                enabled             INTEGER DEFAULT 1,
                created_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS ticket_settings (
                guild_id              INTEGER PRIMARY KEY,
                enabled               INTEGER DEFAULT 1,
                max_per_user          INTEGER DEFAULT 1,
                auto_close_hours      INTEGER DEFAULT 0,
                save_transcripts      INTEGER DEFAULT 1,
                transcript_channel_id INTEGER,
                support_role_id       INTEGER,
                name_format           TEXT DEFAULT 'ticket-{number}',
                updated_at            TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS ticket_categories (
                id                INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id          INTEGER NOT NULL,
                name              TEXT NOT NULL,
                emoji             TEXT DEFAULT '🎫',
                viewer_roles      TEXT DEFAULT '[]',
                closer_roles      TEXT DEFAULT '[]',
                auto_assign_roles TEXT DEFAULT '[]',
                open_embed        TEXT DEFAULT '{}',
                enabled           INTEGER DEFAULT 1,
                sort_order        INTEGER DEFAULT 0,
                created_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_tc_guild
            ON ticket_categories(guild_id)
        """)

        # TASK 4 — Ticket Config: "who can open this category" gate.
        # Without this, every enabled category was shown to every
        # member with no way to restrict it — TicketTool-style configs
        # always let you gate a ticket type behind a role (e.g. only
        # @Verified can open "Ban Appeal"). NULL = open to everyone,
        # same as today's behavior, so this is additive/non-breaking.
        try:
            cursor = await db.execute("PRAGMA table_info(ticket_categories)")
            cols = [c[1] for c in await cursor.fetchall()]
            if "required_role_id" not in cols:
                await db.execute(
                    "ALTER TABLE ticket_categories ADD COLUMN required_role_id INTEGER")
                await db.commit()
        except Exception as e:
            print(f"[MIGRATION] ticket_categories.required_role_id: {e}")

        await db.execute("""
            CREATE TABLE IF NOT EXISTS ticket_panels (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id   INTEGER NOT NULL,
                name       TEXT,
                channel_id INTEGER,
                embed_data TEXT DEFAULT '{}',
                buttons    TEXT DEFAULT '[]',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_tp_guild
            ON ticket_panels(guild_id)
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS ticket_ratings (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id   INTEGER NOT NULL,
                ticket_id  INTEGER,
                user_id    INTEGER NOT NULL,
                rating     INTEGER NOT NULL,
                comment    TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_trat_guild
            ON ticket_ratings(guild_id)
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS report_config (
                guild_id          INTEGER PRIMARY KEY,
                enabled           INTEGER DEFAULT 0,
                report_channel_id INTEGER,
                staff_role_id     INTEGER,
                updated_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS reports (
                id                 INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id           INTEGER NOT NULL,
                reporter_id        INTEGER NOT NULL,
                reporter_name      TEXT NOT NULL,
                reported_user_id   INTEGER NOT NULL,
                reported_user_name TEXT NOT NULL,
                message_id         INTEGER NOT NULL,
                channel_id         INTEGER NOT NULL,
                report_message_id  INTEGER,
                report_channel_id  INTEGER,
                message_content    TEXT,
                message_jump_url   TEXT,
                reason             TEXT,
                status             TEXT DEFAULT 'open',
                created_at         TEXT
            )
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_reports_guild
            ON reports(guild_id)
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_reports_status
            ON reports(guild_id, status)
        """)

        # Migration: Add resolved_by tracking for reports
        try:
            cursor = await db.execute("PRAGMA table_info(reports)")
            cols = [c[1] for c in await cursor.fetchall()]
            if "resolved_by_id" not in cols:
                await db.execute(
                    "ALTER TABLE reports ADD COLUMN resolved_by_id INTEGER")
                await db.commit()
            if "resolved_by_name" not in cols:
                await db.execute(
                    "ALTER TABLE reports ADD COLUMN resolved_by_name TEXT")
                await db.commit()
        except Exception as e:
            print(f"[MIGRATION] reports.resolved_by: {e}")

        await db.execute("""
            CREATE TABLE IF NOT EXISTS bot_status (
                id                INTEGER PRIMARY KEY CHECK (id = 1),
                started_at        TEXT,
                last_heartbeat    TEXT,
                guild_count       INTEGER DEFAULT 0,
                latency_ms        INTEGER DEFAULT 0,
                loaded_cogs       TEXT DEFAULT '[]',
                failed_cogs       TEXT DEFAULT '[]',
                last_error        TEXT,
                last_error_at     TEXT,
                discord_py_version TEXT,
                python_version    TEXT
            )
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS dashboard_users (
                id               INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id         INTEGER NOT NULL,
                user_id          INTEGER NOT NULL,
                permission_level TEXT NOT NULL,
                added_by         INTEGER,
                added_by_name    TEXT,
                enabled          INTEGER DEFAULT 1,
                added_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_du_guild
            ON dashboard_users(guild_id)
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_du_user
            ON dashboard_users(user_id)
        """)

        # SECURITY / DATA-INTEGRITY FIX (dark-fixes pass #7):
        # dashboard_users had NO unique constraint on (guild_id,
        # user_id) — only the surrogate `id` AUTOINCREMENT column was
        # unique. Two places relied on "INSERT OR IGNORE" actually
        # ignoring a duplicate (guild_id, user_id) pair:
        #   - ensure_owner_access(), called from init_db() on EVERY
        #     process start (bot AND dashboard both call init_db())
        #   - add_guild_owner(), called from on_guild_join and the
        #     select_guild() auto-grant path
        # Without a real UNIQUE index, "INSERT OR IGNORE" never had
        # anything to conflict against, so a new surrogate-keyed row
        # was silently inserted every single time — meaning the owner
        # accumulated a fresh duplicate `dashboard_users` row on every
        # bot/dashboard restart.
        #
        # This directly broke "Remove User" in the dashboard
        # (config_access()'s remove_user()): that route deletes by a
        # single surrogate `id`, so removing one duplicate row left
        # every other duplicate (still enabled=1, same guild_id +
        # user_id) granting that user access — access revocation
        # silently failed to actually revoke anything as soon as more
        # than one duplicate existed, which was virtually guaranteed
        # for the owner given the every-restart insert above.
        #
        # Migration: dedupe first (a real UNIQUE index creation fails
        # outright if duplicate rows already exist on disk), keeping
        # one row per (guild_id, user_id) — preferring 'owner' over
        # 'admin' over 'moderator' if levels ever differed across
        # duplicates, then the highest id (most recent) as a
        # tiebreaker — then create the UNIQUE index. From this point
        # forward every existing "INSERT OR IGNORE ... dashboard_users"
        # call site (ensure_owner_access, add_guild_owner) actually
        # ignores true duplicates instead of accumulating new rows,
        # and a single "Remove User" delete is guaranteed to be the
        # only row for that (guild_id, user_id) pair.
        try:
            cursor = await db.execute("""
                SELECT COUNT(*) FROM (
                    SELECT guild_id, user_id FROM dashboard_users
                    GROUP BY guild_id, user_id HAVING COUNT(*) > 1
                )
            """)
            dup_groups = (await cursor.fetchone())[0]

            if dup_groups:
                await db.execute("""
                    DELETE FROM dashboard_users
                    WHERE id NOT IN (
                        SELECT id FROM (
                            SELECT id,
                                   ROW_NUMBER() OVER (
                                       PARTITION BY guild_id, user_id
                                       ORDER BY
                                           CASE permission_level
                                               WHEN 'owner' THEN 0
                                               WHEN 'admin' THEN 1
                                               WHEN 'moderator' THEN 2
                                               ELSE 3
                                           END ASC,
                                           id DESC
                                   ) AS rn
                            FROM dashboard_users
                        )
                        WHERE rn = 1
                    )
                """)
                await db.commit()
                print(f"[MIGRATION] dashboard_users: deduped "
                      f"{dup_groups} (guild_id, user_id) group(s) "
                      f"with duplicate rows")

            await db.execute("""
                CREATE UNIQUE INDEX IF NOT EXISTS idx_du_unique
                ON dashboard_users(guild_id, user_id)
            """)
            await db.commit()
        except Exception as e:
            print(f"[MIGRATION] dashboard_users unique index: {e}")

        await db.execute("""
            CREATE TABLE IF NOT EXISTS audit_log (
                id                INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id          INTEGER NOT NULL,
                user_id           INTEGER NOT NULL,
                user_display_name TEXT NOT NULL,
                target_id         INTEGER,
                target_name       TEXT,
                action            TEXT NOT NULL,
                details           TEXT,
                page              TEXT,
                ip_address        TEXT,
                created_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_al_guild
            ON audit_log(guild_id)
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_al_date
            ON audit_log(created_at)
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS command_toggles (
                id                    INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id              INTEGER NOT NULL,
                command_name          TEXT NOT NULL,
                enabled               INTEGER DEFAULT 1,
                allowed_roles         TEXT,
                allowed_channels      TEXT,
                cooldown_seconds      INTEGER DEFAULT 0,
                aliases               TEXT,
                enabled_roles         TEXT,
                disabled_roles        TEXT,
                enabled_channels      TEXT,
                disabled_channels     TEXT,
                delete_user_msg       INTEGER DEFAULT 0,
                delete_bot_reply      INTEGER DEFAULT 0,
                delete_bot_after      INTEGER DEFAULT 0,
                custom_cooldown       TEXT,
                success_message       TEXT,
                error_message         TEXT,
                ephemeral             INTEGER DEFAULT 0,
                dm_response           INTEGER DEFAULT 0,
                bypass_cooldown_roles TEXT,
                require_permission    TEXT,
                owner_only            INTEGER DEFAULT 0,
                cmd_emoji             TEXT,
                category_color        TEXT,
                hide_from_help        INTEGER DEFAULT 0,
                updated_at            TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(guild_id, command_name)
            )
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_ct_guild
            ON command_toggles(guild_id)
        """)
        # Ensure unique index exists for ON CONFLICT(guild_id, command_name) UPSERT queries
        await db.execute("""
            DELETE FROM command_toggles
            WHERE id NOT IN (
                SELECT MAX(id)
                FROM command_toggles
                GROUP BY guild_id, command_name
            )
        """)
        await db.execute("""
            CREATE UNIQUE INDEX IF NOT EXISTS idx_ct_guild_cmd
            ON command_toggles(guild_id, command_name)
        """)
        # Clean up legacy/removed fun commands, work command, and non-existent ghost commands
        await db.execute("""
            DELETE FROM command_toggles
            WHERE command_name IN (
                'work', 'hug', 'pat', 'slap', 'kiss', 'poke',
                'cuddle', 'wave', 'bite', 'cry', 'dance', 'highfive',
                '8ball', 'coinflip', 'buy', 'event_end',
                'ticket_claim', 'ticket_transfer'
            )
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS scheduled_messages (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id        INTEGER NOT NULL,
                channel_id      INTEGER NOT NULL,
                message_text    TEXT,
                embed_data      TEXT,
                send_at         TIMESTAMP NOT NULL,
                repeat_type     TEXT,
                repeat_interval INTEGER,
                last_sent       TIMESTAMP,
                enabled         INTEGER DEFAULT 1,
                created_by      INTEGER NOT NULL,
                created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS backup_log (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                filename   TEXT NOT NULL,
                size_bytes INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Server Tags — Tag-Loyalty Missions + Cross-Server Join Reward.
        # Both features read/write these tables via cogs/tagmissions.py
        # and cogs/tagpartners.py, which are otherwise self-contained
        # (they grant rewards through the existing utils/reward_engine.py,
        # same as every other reward source in this project).
        await db.execute("""
            CREATE TABLE IF NOT EXISTS tag_missions (
                id                    INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id              INTEGER NOT NULL,
                title                 TEXT NOT NULL,
                confirm_message       TEXT NOT NULL DEFAULT 'Confirmed — wait until the mission ends to receive your prize.',
                not_wearing_message   TEXT NOT NULL DEFAULT 'You need to be wearing this server''s tag to confirm.',
                success_message       TEXT NOT NULL DEFAULT 'Mission complete! Your reward has been sent.',
                failure_message       TEXT NOT NULL DEFAULT 'You removed the server tag before the mission ended — no reward this time.',
                already_message       TEXT NOT NULL DEFAULT 'You already confirmed participation in this mission.',
                reward_type           TEXT NOT NULL,
                reward_amount         TEXT,
                reward_role_id        INTEGER,
                reward_duration_hours INTEGER,
                channel_id            INTEGER,
                message_id            INTEGER,
                starts_at             TIMESTAMP NOT NULL,
                ends_at               TIMESTAMP NOT NULL,
                status                TEXT NOT NULL DEFAULT 'scheduled',
                created_by            INTEGER,
                created_at            TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_tagm_guild
            ON tag_missions(guild_id)
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS tag_mission_participants (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                mission_id   INTEGER NOT NULL,
                guild_id     INTEGER NOT NULL,
                user_id      INTEGER NOT NULL,
                confirmed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                outcome      TEXT,
                resolved_at  TIMESTAMP,
                UNIQUE(mission_id, user_id)
            )
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_tagmp_guild
            ON tag_mission_participants(guild_id, mission_id)
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS tag_partner_rewards (
                id               INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id         INTEGER NOT NULL,
                partner_guild_id INTEGER NOT NULL,
                partner_label    TEXT,
                reward_type      TEXT NOT NULL,
                reward_amount    TEXT,
                reward_role_id   INTEGER,
                welcome_message  TEXT,
                enabled          INTEGER DEFAULT 1,
                created_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(guild_id, partner_guild_id)
            )
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_tagpr_guild
            ON tag_partner_rewards(guild_id)
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS tag_join_reward_log (
                id               INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id         INTEGER NOT NULL,
                partner_guild_id INTEGER NOT NULL,
                user_id          INTEGER NOT NULL,
                rewarded_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(guild_id, partner_guild_id, user_id)
            )
        """)

        # SECURITY / CORRECTNESS FIX: twitch_config.give_role_id used to
        # grant the "live" role to whichever guild member happened to be
        # first in Discord's member iteration order — there was no
        # stored link between a Twitch username and the Discord member
        # who owns it. This column is that missing link, set via
        # /twitch_setup's new `streamer` option or the dashboard; the
        # role grant is skipped (not guessed) when it's unset.
        try:
            cursor = await db.execute("PRAGMA table_info(twitch_config)")
            cols = [c[1] for c in await cursor.fetchall()]
            if "discord_user_id" not in cols:
                await db.execute(
                    "ALTER TABLE twitch_config ADD COLUMN discord_user_id INTEGER")
                await db.commit()
        except Exception as e:
            print(f"[MIGRATION] twitch_config.discord_user_id: {e}")

        await db.commit()

        # SUPER-ADMIN BYPASS MIGRATION: the old ensure_owner_access()
        # (removed) used to auto-seed the developer (OWNER_DISCORD_ID)
        # as a visible 'owner' dashboard_users row in every guild.
        # That's replaced by a guild-blind bypass (see
        # dashboard/permissions.py's is_trusted_super_admin) that
        # never writes a row at all, so the developer stays out of
        # Current Access. This is a one-time cleanup of rows that old
        # mechanism already wrote — scoped to the legacy 'auto-setup'
        # label specifically, so it can never touch the NEW per-guild
        # real-owner rows add_guild_owner() writes going forward
        # (those use a different label, 'guild-owner-sync', precisely
        # so this cleanup can't collide with a guild the developer
        # happens to genuinely, personally own on Discord too). Safe
        # to leave running forever — a no-op once the legacy rows are
        # gone.
        try:
            cursor = await db.execute("""
                SELECT COUNT(*) FROM dashboard_users
                WHERE user_id = ? AND added_by_name = 'auto-setup'
            """, (OWNER_DISCORD_ID,))
            legacy_count = (await cursor.fetchone())[0]
            if legacy_count:
                await db.execute("""
                    DELETE FROM dashboard_users
                    WHERE user_id = ? AND added_by_name = 'auto-setup'
                """, (OWNER_DISCORD_ID,))
                await db.commit()
                print(f"[MIGRATION] Removed {legacy_count} legacy "
                      f"auto-setup dashboard_users row(s) for the "
                      f"developer — access is now via the guild-blind "
                      f"bypass, not a DB row.")
        except Exception as e:
            print(f"[MIGRATION] developer legacy row cleanup: {e}")

    from utils.level_claims import backfill_legacy_claims, ensure_tables
    await ensure_tables()
    await backfill_legacy_claims()

    # Read-only Discord recovery for interrupted/uncertain emoji creates. This
    # is scheduled, never awaited: startup does not block on the network and no
    # startup path may create or delete Discord resources.
    from utils.shop_emoji import schedule_startup_reconciliation
    schedule_startup_reconciliation()

    print("✅ Database initialized — all tables ready")
    print(f"✅ Developer bypass active for user ID: {OWNER_DISCORD_ID} "
          f"(guild-blind, never written to dashboard_users)")


async def add_guild_owner(guild_id: int, owner_discord_id: int):
    """
    Grants dashboard 'owner' access to a guild's REAL Discord server
    owner (guild.owner_id, passed in by the caller — this file has no
    live Discord data of its own). Not used for the developer's own
    access anymore — see dashboard/permissions.py's guild-blind
    super-admin bypass, which never writes a dashboard_users row.
    added_by_name is 'guild-owner-sync', deliberately distinct from
    the legacy 'auto-setup' label the old (removed)
    ensure_owner_access() used to write, so init_db()'s one-time
    cleanup of THOSE rows can never collide with a fresh row here.
    """
    async with aiosqlite.connect(DB_PATH) as db:
        # Relies on idx_du_unique(guild_id, user_id) to dedupe repeat
        # calls (on_guild_join firing again, or main.py's on_ready
        # backfill sweep re-running on every reconnect).
        await db.execute("""
            INSERT OR IGNORE INTO dashboard_users
                (guild_id, user_id, permission_level,
                 added_by_name, enabled)
            VALUES (?, ?, 'owner', 'guild-owner-sync', 1)
        """, (guild_id, owner_discord_id))
        await db.commit()
    print(f"✅ Owner access granted for guild {guild_id} (owner={owner_discord_id})")


if __name__ == "__main__":
    asyncio.run(init_db())
